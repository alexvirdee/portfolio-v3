
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'alexvirdee08',
  applicationName: 'portfolio-contact',
  appUid: 'PgJpP8CHqJ6HjKWqzg',
  orgUid: 'G4WZlJhwG4CMNqkQp2',
  deploymentUid: '0db51019-93cc-4c11-934b-3eefd9b4a41b',
  serviceName: 'contact-mailer-dev',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.15',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'contact-mailer-dev-dev-staticSiteMailer', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.staticSiteMailer, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}